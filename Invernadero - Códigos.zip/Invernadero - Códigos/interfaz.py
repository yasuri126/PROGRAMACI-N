# interfaz.py - Lo que se ve en la pantalla y que hace cada boton.
# Pestanas: INICIO, HISTORIAL, CLIMA y AJUSTES.

from pantalla import (NEGRO, BLANCO, GRIS, ROJO, NARANJA, AMARILLO,
                      VERDE, VERDE_OSCURO, CIAN, AZUL)

ALTO_ENCABEZADO = 30
Y_PESTANAS = 284            # las pestanas ocupan de y=284 a y=319
NOMBRES_PESTANAS = ["INICIO", "HISTO", "CLIMA", "AJUST"]

# Filas de la pestana AJUSTES: donde empieza cada una (y) y su alto
Y_FILAS = [34, 68, 102, 136, 170, 204, 238]
ALTO_FILA = 28
# Que ajuste va en cada fila (en el mismo orden que Y_FILAS)
NOMBRES_FILAS = ["modo", "riego", "noche", "tiempo", "umbral", "fallos", "bomba"]

# Numero de cada pestana (para no usar numeros sueltos en el codigo)
INICIO = 0
HISTORIAL = 1
CLIMA = 2
AJUSTES = 3


def color_del_estado(estado):
    if estado == "REGANDO":
        return AZUL
    if estado == "FILTRA":
        return CIAN
    if estado == "SIN AGUA":
        return ROJO
    return VERDE_OSCURO


class Interfaz:

    def __init__(self, pantalla):
        self.p = pantalla
        self.pestana = INICIO
        self.estado_dibujado = ""     # estado con el que se dibujo AJUSTES

    # ---------- Partes fijas ----------

    def mensaje(self, texto):
        # Pantalla completa con un solo mensaje (por ejemplo al arrancar)
        self.p.limpiar(NEGRO)
        self.p.texto(texto, 10, 150, BLANCO, NEGRO, 2)

    def linea(self, texto, y, color=BLANCO, escala=2):
        # Escribe una linea y rellena con espacios para borrar lo anterior
        caracteres = 232 // (8 * escala)
        texto = texto + " " * (caracteres - len(texto))
        self.p.texto(texto[:caracteres], 6, y, color, NEGRO, escala)

    def dibujar_pestanas(self):
        for numero in range(4):
            if numero == self.pestana:
                color = VERDE_OSCURO
            else:
                color = GRIS
            self.p.boton(numero * 60, Y_PESTANAS, 59, 36,
                         NOMBRES_PESTANAS[numero], color, 1)

    def dibujar_encabezado(self, datos):
        color = color_del_estado(datos["estado"])
        self.p.rectangulo(0, 0, 240, ALTO_ENCABEZADO, color)
        hora = "{:02d}:{:02d}".format(datos["hora"][3], datos["hora"][4])
        self.p.texto(hora, 6, 7, BLANCO, color, 2)
        self.p.texto(datos["estado"], 100, 7, BLANCO, color, 2)

    # ---------- Dibujo completo y actualizacion ----------

    def dibujar_todo(self, datos):
        self.p.limpiar(NEGRO)
        self.dibujar_pestanas()
        self.dibujar_contenido(datos)

    def dibujar_contenido(self, datos):
        # Borra la zona del medio y dibuja la pestana elegida desde cero
        self.p.rectangulo(0, ALTO_ENCABEZADO, 240, Y_PESTANAS - ALTO_ENCABEZADO, NEGRO)
        self.dibujar_pestanas()
        self.dibujar_encabezado(datos)
        if self.pestana == AJUSTES:
            self.vista_ajustes(datos)
            self.estado_dibujado = datos["estado"]
        else:
            self.actualizar(datos)

    def actualizar(self, datos):
        # Se llama cada 2 segundos: solo cambia los valores, sin borrar todo
        self.dibujar_encabezado(datos)
        if self.pestana == INICIO:
            self.vista_inicio(datos)
        elif self.pestana == HISTORIAL:
            self.vista_historial(datos)
        elif self.pestana == CLIMA:
            self.vista_clima(datos)
        elif self.pestana == AJUSTES:
            # Para que no parpadee, AJUSTES solo se redibuja si cambio el estado
            # (por ejemplo, para que REGAR pase a DETENER y vuelva)
            if datos["estado"] != self.estado_dibujado:
                self.vista_ajustes(datos)
                self.estado_dibujado = datos["estado"]

    # ---------- Vistas ----------

    def vista_inicio(self, datos):
        # Mensaje principal sobre la planta
        if datos["estado"] == "REGANDO":
            self.linea("Regando...", 40, AZUL)
        elif datos["estado"] == "SIN AGUA":
            self.linea("Revisa deposito", 40, ROJO)
        elif datos["necesita_agua"]:
            self.linea("Tierra seca", 40, NARANJA)
        else:
            self.linea("Planta bien", 40, VERDE)

        # Humedad del suelo con barra y marca del umbral
        self.linea("Suelo: {} %".format(datos["hum_suelo"]), 70)
        self.p.rectangulo(10, 94, 220, 16, GRIS)
        self.p.rectangulo(10, 94, datos["hum_suelo"] * 220 // 100, 16, AZUL)
        marca = 10 + datos["umbral"] * 220 // 100
        self.p.rectangulo(marca, 90, 3, 24, ROJO)
        self.linea("Riega bajo {} %".format(datos["umbral"]), 118, GRIS, 1)

        # Aire dentro del invernadero
        self.linea("Aire: {:.1f} C".format(datos["temp"]), 140)
        self.linea("Humedad: {:.0f} %".format(datos["hum_aire"]), 166)

        self.linea("Modo: " + datos["modo"], 210)
        self.linea("Riegos hoy: {}".format(datos["riegos_hoy"]), 236)
        if not datos["wifi"]:
            self.linea("Sin WiFi", 262, NARANJA, 1)
        elif datos["nube"]:
            self.linea("WiFi y nube conectados", 262, GRIS, 1)
        else:
            self.linea("WiFi conectado, sin nube", 262, NARANJA, 1)

    def vista_historial(self, datos):
        self.linea("Ultimos riegos", 40, AMARILLO)
        historial = datos["historial"]
        if len(historial) == 0:
            self.linea("Todavia no hay riegos", 70, GRIS, 1)
            return
        y = 66
        # Del mas nuevo al mas antiguo
        for i in range(len(historial) - 1, -1, -1):
            self.linea(historial[i], y, BLANCO, 1)
            y = y + 14

    def vista_clima(self, datos):
        clima = datos["clima"]
        self.linea("Clima en Lima", 40, AMARILLO)
        if not clima.hay_datos:
            self.linea("Sin datos del clima", 80, NARANJA, 1)
            self.linea("Revisa la conexion WiFi", 96, GRIS, 1)
            return
        self.linea("Ahora: {:.1f} C".format(clima.temp_actual), 76)
        self.linea("Maxima: {:.1f} C".format(clima.temp_maxima), 102)
        self.linea("Lluvia: {} %".format(clima.prob_lluvia), 128)
        if clima.hace_calor():
            self.linea("Dia caluroso", 166, NARANJA)
            self.linea("Se riega antes (umbral mas alto)", 192, GRIS, 1)
        else:
            self.linea("Dia templado", 166, VERDE)
            self.linea("Umbral de riego normal", 192, GRIS, 1)

    def fila_ajuste(self, nombre, y):
        # Nombre del ajuste a la izquierda; el boton va a la derecha
        self.p.texto(nombre, 6, y + 6, BLANCO, NEGRO, 2)

    def fila_boton(self, nombre, y, texto_boton, color):
        # Fila con un solo boton
        self.fila_ajuste(nombre, y)
        self.p.boton(130, y, 100, ALTO_FILA, texto_boton, color, 2)

    def fila_numero(self, nombre, y, valor):
        # Fila con botones [-] y [+] y el valor al medio
        self.fila_ajuste(nombre, y)
        self.p.boton(130, y, 30, ALTO_FILA, "-", GRIS, 2)
        self.p.texto("{:2d}".format(valor), 164, y + 6, BLANCO, NEGRO, 2)
        self.p.boton(200, y, 30, ALTO_FILA, "+", GRIS, 2)

    def vista_ajustes(self, datos):
        # Cada fila: texto a la izquierda y boton(es) a la derecha
        self.fila_boton("Modo:", Y_FILAS[0], datos["modo"], AZUL)

        if datos["estado"] == "REGANDO":
            self.fila_boton("Riego:", Y_FILAS[1], "PARAR", ROJO)
        elif datos["estado"] == "SIN AGUA":
            self.fila_boton("Riego:", Y_FILAS[1], "REGAR", GRIS)
        else:
            self.fila_boton("Riego:", Y_FILAS[1], "REGAR", VERDE_OSCURO)

        # Noche: PAUSA = de noche no riega, RIEGA = riega a cualquier hora
        if datos["no_regar_de_noche"]:
            self.fila_boton("Noche:", Y_FILAS[2], "PAUSA", AZUL)
        else:
            self.fila_boton("Noche:", Y_FILAS[2], "RIEGA", GRIS)

        self.fila_numero("Tiempo:", Y_FILAS[3], datos["tiempo_riego"])   # segundos
        self.fila_numero("Umbral:", Y_FILAS[4], datos["umbral_base"])    # % de humedad
        self.fila_numero("Fallos:", Y_FILAS[5], datos["intentos"])       # riegos sin agua

        # Si la bomba se bloqueo por falta de agua, se desbloquea con RESET
        if datos["estado"] == "SIN AGUA":
            self.fila_boton("Bomba:", Y_FILAS[6], "RESET", ROJO)
        else:
            self.fila_boton("Bomba:", Y_FILAS[6], "OK", GRIS)

    # ---------- Toques ----------

    def revisar_toque(self, x, y):
        # Devuelve el nombre de la accion que se toco, o None
        if y >= Y_PESTANAS:
            self.pestana = min(x // 60, 3)
            return "cambiar_pestana"

        if self.pestana == AJUSTES and x >= 130:
            # 1) Buscar en que fila se toco
            fila = ""
            for i in range(len(Y_FILAS)):
                if Y_FILAS[i] <= y < Y_FILAS[i] + ALTO_FILA:
                    fila = NOMBRES_FILAS[i]

            # 2) Ver si fue el boton [-] (izquierda) o [+] (derecha)
            if x < 160:
                lado = "_menos"
            elif x >= 200:
                lado = "_mas"
            else:
                lado = ""

            # 3) Elegir la accion
            if fila == "modo":
                return "cambiar_modo"
            if fila == "riego":
                if self.estado_dibujado == "REGANDO":
                    return "detener"
                return "regar"
            if fila == "noche":
                return "cambiar_noche"
            if fila == "bomba":
                return "reset_bomba"
            if fila == "tiempo" or fila == "umbral" or fila == "fallos":
                if lado != "":
                    return fila + lado      # por ejemplo "tiempo_mas"
        return None
