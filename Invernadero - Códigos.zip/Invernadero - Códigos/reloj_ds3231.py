# reloj_ds3231.py - Libreria del reloj DS3231 (con pila).
# Guarda la fecha y hora aunque se desconecte todo.
# Uso:  reloj = RelojDS3231(sda, scl)
#       reloj.poner_hora(anio, mes, dia, hora, minuto, segundo)
#       anio, mes, dia, hora, minuto, segundo = reloj.leer_hora()

from machine import Pin, I2C


# El DS3231 guarda cada numero en formato BCD: cada cifra en 4 bits.
# Ejemplo: 45 se guarda como 0x45.
def a_bcd(numero):
    return (numero // 10) * 16 + (numero % 10)


def de_bcd(valor):
    return (valor // 16) * 10 + (valor % 16)


class RelojDS3231:

    DIRECCION = 0x68          # direccion I2C del DS3231

    def __init__(self, pin_sda, pin_scl):
        self.i2c = I2C(0, sda=Pin(pin_sda), scl=Pin(pin_scl), freq=100000)
        self.funciona = self.DIRECCION in self.i2c.scan()

    def poner_hora(self, anio, mes, dia, hora, minuto, segundo):
        datos = bytes([a_bcd(segundo), a_bcd(minuto), a_bcd(hora), 1,
                       a_bcd(dia), a_bcd(mes), a_bcd(anio - 2000)])
        self.i2c.writeto_mem(self.DIRECCION, 0x00, datos)

    def leer_hora(self):
        # Devuelve (anio, mes, dia, hora, minuto, segundo)
        d = self.i2c.readfrom_mem(self.DIRECCION, 0x00, 7)
        segundo = de_bcd(d[0] & 0x7F)
        minuto = de_bcd(d[1])
        hora = de_bcd(d[2] & 0x3F)
        dia = de_bcd(d[4])
        mes = de_bcd(d[5] & 0x1F)
        anio = de_bcd(d[6]) + 2000
        return anio, mes, dia, hora, minuto, segundo
