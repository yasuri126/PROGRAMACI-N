# pantalla.py - Manejo de la pantalla TFT ILI9341 y del tactil XPT2046.
# Solo sabe dibujar y leer toques; no sabe nada del invernadero.

from machine import Pin, SPI
import framebuf
import time
import config as cfg

# Colores en formato RGB565
NEGRO = 0x0000
BLANCO = 0xFFFF
GRIS = 0x8410
ROJO = 0xF800
NARANJA = 0xFD20
AMARILLO = 0xFFE0
VERDE = 0x07E0
VERDE_OSCURO = 0x03E0
CIAN = 0x07FF
AZUL = 0x001F


class Pantalla:

    def __init__(self):
        # El tactil comparte el SPI: su CS debe estar en alto ANTES de que el
        # bus empiece a moverse, o escucha los datos de la pantalla y se desactiva
        Pin(cfg.PIN_TACTIL_CS, Pin.OUT, value=1)
        self.spi = SPI(1, baudrate=20000000, sck=Pin(cfg.PIN_SCK),
                       mosi=Pin(cfg.PIN_MOSI), miso=Pin(cfg.PIN_MISO))
        self.cs = Pin(cfg.PIN_CS, Pin.OUT, value=1)
        self.dc = Pin(cfg.PIN_DC, Pin.OUT, value=0)
        self.rst = Pin(cfg.PIN_RESET, Pin.OUT, value=1)
        self.iniciar()

    def enviar_comando(self, comando, datos=None):
        self.cs.value(0)
        self.dc.value(0)                     # DC en 0 = comando
        self.spi.write(bytes([comando]))
        if datos is not None:
            self.dc.value(1)                 # DC en 1 = datos
            self.spi.write(bytes(datos))
        self.cs.value(1)

    def iniciar(self):
        self.rst.value(0)
        time.sleep_ms(50)
        self.rst.value(1)
        time.sleep_ms(150)
        self.enviar_comando(0x01)            # reinicio por software
        time.sleep_ms(150)
        self.enviar_comando(0x11)            # salir del modo dormir
        time.sleep_ms(150)
        self.enviar_comando(0x3A, [0x55])    # 16 bits por pixel

        orientacion = 0
        if cfg.ESPEJO_Y:
            orientacion = orientacion + 0x80
        if cfg.ESPEJO_X:
            orientacion = orientacion + 0x40
        if cfg.ORDEN_BGR:
            orientacion = orientacion + 0x08
        self.enviar_comando(0x36, [orientacion])

        self.enviar_comando(0x29)            # encender la pantalla
        time.sleep_ms(50)

    def elegir_zona(self, x, y, ancho, alto):
        x2 = x + ancho - 1
        y2 = y + alto - 1
        self.enviar_comando(0x2A, [x >> 8, x & 0xFF, x2 >> 8, x2 & 0xFF])
        self.enviar_comando(0x2B, [y >> 8, y & 0xFF, y2 >> 8, y2 & 0xFF])
        self.enviar_comando(0x2C)

    def rectangulo(self, x, y, ancho, alto, color):
        if ancho <= 0 or alto <= 0:
            return
        self.elegir_zona(x, y, ancho, alto)
        fila = bytes([color >> 8, color & 0xFF]) * ancho
        self.cs.value(0)
        self.dc.value(1)
        for i in range(alto):
            self.spi.write(fila)
        self.cs.value(1)

    def limpiar(self, color):
        self.rectangulo(0, 0, cfg.ANCHO, cfg.ALTO, color)

    def texto(self, mensaje, x, y, color, fondo, escala=1):
        # 1) Dibuja el texto en una memoria pequena de 8 pixeles de alto
        ancho = len(mensaje) * 8
        if ancho == 0:
            return
        memoria = bytearray(ancho * 8 * 2)
        dibujo = framebuf.FrameBuffer(memoria, ancho, 8, framebuf.RGB565)
        # framebuf guarda los bytes al reves que la pantalla, por eso se invierten
        dibujo.fill(((fondo & 0xFF) << 8) | (fondo >> 8))
        dibujo.text(mensaje, 0, 0, ((color & 0xFF) << 8) | (color >> 8))

        # 2) Manda la memoria a la pantalla, agrandada segun la escala
        self.elegir_zona(x, y, ancho * escala, 8 * escala)
        self.cs.value(0)
        self.dc.value(1)
        if escala == 1:
            self.spi.write(memoria)
        else:
            # Se dibuja una version grande: cada pixel de la letra se
            # convierte en un cuadrado de escala x escala
            color_al_reves = ((color & 0xFF) << 8) | (color >> 8)
            grande = bytearray(ancho * escala * 8 * escala * 2)
            dibujo_grande = framebuf.FrameBuffer(grande, ancho * escala, 8 * escala,
                                                 framebuf.RGB565)
            dibujo_grande.fill(((fondo & 0xFF) << 8) | (fondo >> 8))
            for fila in range(8):
                for columna in range(ancho):
                    if dibujo.pixel(columna, fila) == color_al_reves:
                        dibujo_grande.fill_rect(columna * escala, fila * escala,
                                                escala, escala, color_al_reves)
            self.spi.write(grande)
        self.cs.value(1)

    def boton(self, x, y, ancho, alto, mensaje, color, escala):
        self.rectangulo(x, y, ancho, alto, color)
        texto_x = x + (ancho - len(mensaje) * 8 * escala) // 2
        texto_y = y + (alto - 8 * escala) // 2
        self.texto(mensaje, texto_x, texto_y, BLANCO, color, escala)


class Tactil:

    def __init__(self, pantalla):
        self.spi = pantalla.spi              # usa el mismo SPI que la pantalla
        self.cs = Pin(cfg.PIN_TACTIL_CS, Pin.OUT, value=1)
        self.irq = Pin(cfg.PIN_TACTIL_IRQ, Pin.IN)   # vale 0 al tocar
        self.armar()

    def armar(self):
        # Una lectura de prueba deja el chip listo para avisar los toques (IRQ)
        self.spi.init(baudrate=1000000)
        respuesta = bytearray(3)
        self.cs.value(0)
        self.spi.write_readinto(bytes([0x90, 0, 0]), respuesta)
        self.cs.value(1)
        self.spi.init(baudrate=20000000)

    def leer_bruto(self):
        if self.irq.value() == 1:
            return None
        self.spi.init(baudrate=1000000)      # el tactil va mas lento
        respuesta = bytearray(2)
        self.cs.value(0)
        self.spi.write(bytes([0xD0]))        # pedir X
        self.spi.readinto(respuesta)
        x = ((respuesta[0] << 8) | respuesta[1]) >> 3
        self.spi.write(bytes([0x90]))        # pedir Y
        self.spi.readinto(respuesta)
        y = ((respuesta[0] << 8) | respuesta[1]) >> 3
        self.cs.value(1)
        self.spi.init(baudrate=20000000)     # volver a la velocidad de la pantalla
        if x == 0 or y == 0 or x == 4095 or y == 4095:
            return None                      # lectura falsa
        return x, y

    def leer(self):
        # Devuelve (x, y) en pixeles o None si no se esta tocando
        bruto = self.leer_bruto()
        if bruto is None:
            return None
        x = (bruto[0] - cfg.TACTIL_X_MIN) * cfg.ANCHO // (cfg.TACTIL_X_MAX - cfg.TACTIL_X_MIN)
        y = (bruto[1] - cfg.TACTIL_Y_MIN) * cfg.ALTO // (cfg.TACTIL_Y_MAX - cfg.TACTIL_Y_MIN)
        if cfg.INVERTIR_X:
            x = cfg.ANCHO - 1 - x
        if cfg.INVERTIR_Y:
            y = cfg.ALTO - 1 - y
        x = max(0, min(cfg.ANCHO - 1, x))
        y = max(0, min(cfg.ALTO - 1, y))
        return x, y
