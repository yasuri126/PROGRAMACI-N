# sensores.py - Lectura de los sensores: aire (DHT22) y humedad del suelo.

from machine import Pin, ADC
import dht
import time
import config as cfg


class SensorAmbiente:
    # Temperatura y humedad del aire dentro del invernadero (DHT22)

    def __init__(self):
        # Se arranca con el sensor apagado: en la primera lectura se prende.
        # Asi se reinicia aunque haya quedado colgado de antes.
        self.energia = Pin(cfg.PIN_DHT_ENERGIA, Pin.OUT, value=0)
        self.sensor = dht.DHT22(Pin(cfg.PIN_DHT))
        self.temperatura = 0
        self.humedad = 0
        self.funciona = False
        self.fallos_seguidos = 0
        self.apagado = True        # True mientras se esta reiniciando

    def reiniciar(self):
        # Corta la energia del sensor; se vuelve a prender en la siguiente lectura.
        # Se usa al apagar la bomba, porque su arranque "cuelga" al DHT22.
        self.energia.off()
        self.apagado = True
        self.fallos_seguidos = 0

    def leer(self):
        # Si se estaba reiniciando, se vuelve a prender y se espera
        # a la siguiente lectura para que el sensor arranque bien
        if self.apagado:
            self.energia.on()
            self.apagado = False
            return

        try:
            self.sensor.measure()
            self.temperatura = self.sensor.temperature()
            self.humedad = self.sensor.humidity()
            self.fallos_seguidos = 0
            self.funciona = True
        except OSError:
            # Una lectura fallida suelta es normal (por ejemplo, ruido al
            # arrancar la bomba). Se quedan los ultimos valores y solo se
            # avisa error si falla varias veces seguidas.
            self.fallos_seguidos = self.fallos_seguidos + 1
            if self.fallos_seguidos >= 3:
                self.funciona = False
                # El ruido de la bomba puede "colgar" al sensor:
                # se le corta la energia para reiniciarlo
                self.energia.off()
                self.apagado = True
                self.fallos_seguidos = 0


class SensorSuelo:
    # Humedad de la tierra (sensor resistivo)

    def __init__(self):
        self.energia = Pin(cfg.PIN_SUELO_ENERGIA, Pin.OUT, value=0)
        self.adc = ADC(cfg.PIN_SUELO_ADC)
        self.ultimas = []        # ultimas lecturas para sacar el promedio

    def leer_crudo(self):
        # Se prende solo un momento para que las patitas no se oxiden
        self.energia.on()
        time.sleep_ms(100)
        valor = self.adc.read_u16()
        self.energia.off()
        return valor

    def leer_porcentaje(self):
        valor = self.leer_crudo()
        # Seco = valor alto, mojado = valor bajo. Se convierte a 0-100 %
        porcentaje = (cfg.SUELO_SECO - valor) * 100 // (cfg.SUELO_SECO - cfg.SUELO_MOJADO)
        if porcentaje < 0:
            porcentaje = 0
        if porcentaje > 100:
            porcentaje = 100

        # Promedio movil para que una lectura rara no active la bomba
        self.ultimas.append(porcentaje)
        if len(self.ultimas) > cfg.MUESTRAS_PROMEDIO:
            self.ultimas.pop(0)
        return sum(self.ultimas) // len(self.ultimas)
