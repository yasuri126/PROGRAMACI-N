# hora.py - Da la hora de Lima al resto del programa.
# Usa el reloj DS3231; si el reloj falla, usa la hora interna de la Pico.

import time
import ntptime
import config as cfg
from reloj_ds3231 import RelojDS3231


class Hora:

    def __init__(self):
        self.reloj = RelojDS3231(cfg.PIN_SDA, cfg.PIN_SCL)

    def sincronizar_con_internet(self):
        # Pide la hora a internet una vez y se la guarda al reloj
        try:
            ntptime.settime()
        except OSError:
            return False
        t = time.localtime(time.time() + cfg.ZONA_HORARIA * 3600)
        if self.reloj.funciona:
            self.reloj.poner_hora(t[0], t[1], t[2], t[3], t[4], t[5])
        return True

    def ahora(self):
        # Devuelve (anio, mes, dia, hora, minuto, segundo)
        if self.reloj.funciona:
            try:
                return self.reloj.leer_hora()
            except OSError:
                pass
        t = time.localtime(time.time() + cfg.ZONA_HORARIA * 3600)
        return t[0], t[1], t[2], t[3], t[4], t[5]
