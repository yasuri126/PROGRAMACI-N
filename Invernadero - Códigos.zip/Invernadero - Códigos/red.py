# red.py - Conexion al WiFi.

import network
import time


def conectar(ssid, clave, segundos=10):
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if wlan.isconnected():
        return True
    wlan.connect(ssid, clave)
    for i in range(segundos * 2):
        if wlan.isconnected():
            return True
        time.sleep(0.5)
    # No se pudo conectar: se apaga el chip WiFi para que no siga buscando
    # la red en segundo plano (eso interrumpe la lectura del DHT22)
    wlan.disconnect()
    wlan.active(False)
    return False


def esta_conectado():
    return network.WLAN(network.STA_IF).isconnected()
