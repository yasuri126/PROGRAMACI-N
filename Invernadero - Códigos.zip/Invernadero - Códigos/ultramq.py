# ultramq.py — MQTT "caja negra" para MicroPython (Raspberry Pi Pico W)
# API mínima para estudiantes:
#   from ultramq import begin, send, on_message, receive
#   begin(SSID, PASS, BROKER, BASE)      # conecta y deja un hilo atendiendo MQTT
#   send(data)                           # data: dict/list -> JSON, otros -> str
#   on_message(fn)                       # fn(payload) se llama al llegar comando (BASE/cmd)
#   receive(timeout_ms=0) -> payload|None# lectura simple tipo cola (sin callback)
#
# Topics por convención:
#   Publicación: BASE/telemetry
#   Comandos:    BASE/cmd

import time, json, ubinascii, _thread
from machine import Pin
import network
from umqtt.simple import MQTTClient

# ----- Estado interno (oculto) -----
_wlan = network.WLAN(network.STA_IF)
_cli = None
_base = ""
_topic_out = ""
_topic_cmd = ""
_broker = ""
_port = 1883

_led = None
_run = False
_lock = _thread.allocate_lock()
_inbox = []          # cola de comandos recibidos (payload ya parseado si es JSON)
_user_cb = None

def _wifi_connect(ssid, password):
    if not _wlan.active():
        _wlan.active(True)
    if not _wlan.isconnected():
        print("ultramq: conectando Wi-Fi…")
        _wlan.connect(ssid, password)
        t0 = time.ticks_ms()
        while not _wlan.isconnected():
            if time.ticks_diff(time.ticks_ms(), t0) > 15000:
                raise RuntimeError("ultramq: timeout Wi-Fi")
            time.sleep_ms(200)
    print("ultramq: Wi-Fi OK", _wlan.ifconfig())

def _client_new():
    try:
        import machine
        cid = b"pico-" + ubinascii.hexlify(machine.unique_id())
    except:
        cid = b"pico-" + ubinascii.hexlify(ubinascii.random(4))
    c = MQTTClient(cid, _broker, _port, keepalive=60)
    c.set_callback(_on_msg)
    c.set_last_will(_base + "/state", b'{"status":"offline"}', retain=False, qos=0)
    return c

def _connect_mqtt():
    global _cli
    _cli = _client_new()
    _cli.connect(clean_session=True)
    try:
        _cli.publish(_base + "/state", b'{"status":"online"}', retain=False, qos=0)
    except:
        pass
    _cli.subscribe(_topic_cmd, qos=1)
    print("ultramq: MQTT OK →", _broker)

def _reconnect():
    global _cli
    print("ultramq: reconectando…")
    try:
        if _cli: _cli.disconnect()
    except:
        pass
    time.sleep_ms(300)
    _connect_mqtt()

def _on_msg(topic_b, msg_b):
    # decode -> str, intentar JSON
    try:
        text = msg_b.decode()
    except:
        text = str(msg_b)
    payload = text
    try:
        payload = json.loads(text)
    except:
        pass

    # callback del usuario si existe
    if _user_cb:
        try:
            _user_cb(payload)
            return
        except Exception as e:
            print("ultramq: error callback:", e)

    # si no hay callback, encolar para receive()
    with _lock:
        _inbox.append(payload)

def _loop_thread():
    # hilo de servicio: atiende MQTT + latido LED + reconexión
    last = time.ticks_ms()
    while _run:
        try:
            if _cli:
                _cli.check_msg()
        except:
            _reconnect()
        # latido LED cada 500 ms
        if _led and time.ticks_diff(time.ticks_ms(), last) > 500:
            _led.toggle()
            last = time.ticks_ms()
        time.sleep_ms(40)

# ----- API pública -----

def begin(ssid, password, broker, base, port=1883, led_status=True):
    """Conecta Wi-Fi y MQTT. Deja un hilo atendiendo todo en 2º plano.
       Publica en BASE/telemetry; escucha en BASE/cmd."""
    global _base, _topic_out, _topic_cmd, _broker, _port, _led, _run
    _base = base.rstrip("/")
    _topic_out = _base + "/telemetry"
    _topic_cmd = _base + "/cmd"
    _broker, _port = broker, port

    try:
        _led = Pin("LED", Pin.OUT) if led_status else None
    except:
        _led = None

    _wifi_connect(ssid, password)
    _connect_mqtt()

    _run = True
    try:
        _thread.start_new_thread(_loop_thread, ())
    except Exception as e:
        _run = False
        raise RuntimeError("ultramq: no se pudo iniciar hilo de servicio") from e

    print("ultramq: listo. out:", _topic_out, "| cmd:", _topic_cmd)

def send(data, retain=False, qos=0):
    """Publicar telemetría (dict/list -> JSON; otros -> str)."""
    if isinstance(data, (dict, list)):
        msg = json.dumps(data)
    else:
        msg = str(data)
    try:
        _cli.publish(_topic_out, msg, retain=retain, qos=qos)
    except:
        _reconnect()
        _cli.publish(_topic_out, msg, retain=retain, qos=qos)

def on_message(fn):
    """Registrar callback simple: fn(payload)."""
    global _user_cb
    _user_cb = fn

def receive(timeout_ms=0):
    """Obtener el siguiente comando (str o dict). Si timeout_ms>0, espera hasta
       ese tiempo y retorna None si no llegó nada."""
    t0 = time.ticks_ms()
    while True:
        with _lock:
            if _inbox:
                return _inbox.pop(0)
        if timeout_ms <= 0:
            return None
        if time.ticks_diff(time.ticks_ms(), t0) >= timeout_ms:
            return None
        time.sleep_ms(20)

def is_connected():
    """Devuelve True si WiFi y MQTT están conectados."""
    try:
        return _wlan.isconnected() and _cli is not None
    except:
        return False
