# clima.py - Consulta el clima de Lima en internet (Open-Meteo, gratis y sin clave).

import config as cfg

try:
    import requests
except ImportError:
    import urequests as requests


class Clima:

    def __init__(self):
        self.temp_actual = None
        self.temp_maxima = None
        self.prob_lluvia = None
        self.hay_datos = False

    def actualizar(self):
        url = ("https://api.open-meteo.com/v1/forecast"
               "?latitude={}&longitude={}"
               "&current=temperature_2m"
               "&daily=temperature_2m_max,precipitation_probability_max"
               "&timezone=America%2FLima&forecast_days=1").format(cfg.LATITUD, cfg.LONGITUD)
        try:
            respuesta = requests.get(url)
            datos = respuesta.json()
            respuesta.close()
            self.temp_actual = datos["current"]["temperature_2m"]
            self.temp_maxima = datos["daily"]["temperature_2m_max"][0]
            self.prob_lluvia = datos["daily"]["precipitation_probability_max"][0]
            self.hay_datos = True
        except Exception as error:
            print("No se pudo leer el clima:", error)
            self.hay_datos = False
        return self.hay_datos

    def hace_calor(self):
        if self.temp_maxima is None:
            return False
        return self.temp_maxima >= cfg.TEMP_CALOR
