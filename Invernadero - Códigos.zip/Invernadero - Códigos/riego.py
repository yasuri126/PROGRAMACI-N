# riego.py - Las reglas que deciden cuando regar.
#
# Estados:
#   NORMAL   -> bomba apagada, vigila la humedad de la tierra
#   REGANDO  -> la bomba esta prendida
#   FILTRA   -> acaba de regar: espera a que el agua se filtre hasta el sensor
#               antes de volver a decidir (para no regar de mas)
#   SIN AGUA -> regó varias veces y la humedad no subio: el deposito esta vacio
#               o la manguera esta tapada. La bomba se bloquea hasta pulsar
#               RESET (cuantas veces seguidas se configura en config.py)
# Modos:
#   AUTO   -> riega solo cuando la tierra esta seca
#   MANUAL -> solo riega cuando alguien pulsa REGAR AHORA
# Opcion "no regar de noche": en AUTO no riega fuera del horario de config.py

import time
import config as cfg


class ControlRiego:

    def __init__(self):
        self.estado = "NORMAL"
        self.modo = "AUTO"
        self.umbral = cfg.UMBRAL_SECO
        self.inicio_estado = time.ticks_ms()
        self.humedad_al_empezar = 0
        self.tipo_riego = "auto"
        self.fallos = 0
        self.riego_manual_pedido = False
        self.detener_pedido = False
        self.intentos_sin_agua = cfg.FALLOS_PARA_ALERTA   # se cambia desde la pantalla
        self.tiempo_riego = cfg.TIEMPO_RIEGO_S              # se cambia desde la pantalla
        self.no_regar_de_noche = cfg.NO_REGAR_DE_NOCHE   # se cambia desde la pantalla

    # ---------- Funciones de ayuda ----------

    def cambiar_estado(self, nuevo):
        self.estado = nuevo
        self.inicio_estado = time.ticks_ms()

    def segundos_en_estado(self):
        return time.ticks_diff(time.ticks_ms(), self.inicio_estado) // 1000

    def umbral_actual(self, hace_calor):
        # Si hace calor en Lima, la tierra se seca mas rapido: se riega antes
        if hace_calor:
            return self.umbral + cfg.AJUSTE_CALOR
        return self.umbral

    def necesita_agua(self, humedad, hace_calor):
        return humedad < self.umbral_actual(hace_calor)

    def es_hora_permitida(self, hora):
        if not self.no_regar_de_noche:
            return True
        return cfg.HORA_INICIO_RIEGO <= hora < cfg.HORA_FIN_RIEGO

    def empezar_riego(self, humedad, tipo):
        self.humedad_al_empezar = humedad
        self.tipo_riego = tipo
        self.cambiar_estado("REGANDO")

    # ---------- Logica principal ----------

    def actualizar(self, humedad, hora, hace_calor):
        # Se llama cada vez que se leen los sensores.
        # Devuelve los datos de un riego cuando termina, o None.
        riego_terminado = None

        if self.estado == "NORMAL" or self.estado == "FILTRA":
            # El riego manual se puede pedir aunque este en reposo
            if self.riego_manual_pedido:
                self.riego_manual_pedido = False
                self.empezar_riego(humedad, "manual")
                return None

        if self.estado == "NORMAL":
            if (self.modo == "AUTO" and self.necesita_agua(humedad, hace_calor)
                    and self.es_hora_permitida(hora)):
                self.empezar_riego(humedad, "auto")

        elif self.estado == "REGANDO":
            segundos = self.segundos_en_estado()
            # El automatico para cuando la tierra ya esta humeda
            terminar = False
            if self.tipo_riego == "auto" and humedad >= cfg.UMBRAL_HUMEDO:
                terminar = True
            # Los dos paran al cumplir el tiempo de riego (tambien es seguridad:
            # la bomba nunca queda prendida mas de ese tiempo)
            if segundos >= self.tiempo_riego:
                terminar = True
            # Alguien pulso DETENER
            if self.detener_pedido:
                self.detener_pedido = False
                terminar = True
            if terminar:
                riego_terminado = {
                    "tipo": self.tipo_riego,
                    "duracion": segundos,
                    "antes": self.humedad_al_empezar,
                    "despues": humedad,
                }
                self.cambiar_estado("FILTRA")

        elif self.estado == "FILTRA":
            if self.segundos_en_estado() >= cfg.TIEMPO_FILTRA_S:
                # Solo se revisa en riegos automaticos (el manual puede ser con tierra mojada)
                if self.tipo_riego == "auto":
                    subida = humedad - self.humedad_al_empezar
                    if subida < cfg.SUBIDA_MINIMA:
                        self.fallos = self.fallos + 1
                    else:
                        self.fallos = 0
                if self.fallos >= self.intentos_sin_agua:
                    self.cambiar_estado("SIN AGUA")
                else:
                    self.cambiar_estado("NORMAL")

        # En "SIN AGUA" no se hace nada hasta que alguien pulse RESET de la bomba

        return riego_terminado

    def bomba_debe_estar_encendida(self):
        return self.estado == "REGANDO"

    # ---------- Acciones desde la pantalla ----------

    def pedir_riego_manual(self):
        if self.estado == "NORMAL" or self.estado == "FILTRA":
            self.riego_manual_pedido = True

    def detener_riego(self):
        if self.estado == "REGANDO":
            self.detener_pedido = True

    def cambiar_modo(self):
        if self.modo == "AUTO":
            self.modo = "MANUAL"
        else:
            self.modo = "AUTO"

    def cambiar_noche(self):
        # Activa o desactiva la regla de no regar de noche
        if self.no_regar_de_noche:
            self.no_regar_de_noche = False
        else:
            self.no_regar_de_noche = True

    def cambiar_tiempo(self, cambio):
        # Segundos que dura cada riego
        self.tiempo_riego = self.tiempo_riego + cambio
        if self.tiempo_riego < 2:
            self.tiempo_riego = 2
        if self.tiempo_riego > 20:
            self.tiempo_riego = 20

    def cambiar_intentos(self, cambio):
        # Cuantos riegos seguidos sin que suba la humedad para marcar SIN AGUA
        self.intentos_sin_agua = self.intentos_sin_agua + cambio
        if self.intentos_sin_agua < 1:
            self.intentos_sin_agua = 1
        if self.intentos_sin_agua > 5:
            self.intentos_sin_agua = 5

    def cambiar_umbral(self, cambio):
        self.umbral = self.umbral + cambio
        if self.umbral < 10:
            self.umbral = 10
        if self.umbral > 80:
            self.umbral = 80

    def reset_bomba(self):
        if self.estado == "SIN AGUA":
            self.fallos = 0
            self.cambiar_estado("NORMAL")
