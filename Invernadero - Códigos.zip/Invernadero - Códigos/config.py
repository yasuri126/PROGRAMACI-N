# config.py - Todos los valores que se pueden ajustar del invernadero.
# Si hay que cambiar un pin, un umbral o un tiempo, se cambia SOLO aqui.

# ---------- WiFi y ubicacion ----------
WIFI_SSID = "LIZ"
WIFI_CLAVE = "LIZPELLE891"
LATITUD = -12.05          # Lima
LONGITUD = -77.04
ZONA_HORARIA = -5         # Lima = UTC-5

# ---------- Nube (MQTT con la libreria ultramq del profe) ----------
USAR_NUBE = True
MQTT_BROKER = "broker.hivemq.com"
MQTT_BASE = "invernadero_ari_k4p9"   # nombre unico para no cruzarse con otros grupos

# ---------- Pines ----------
PIN_DHT = 15              # DHT22 (temperatura y humedad del aire)
PIN_DHT_ENERGIA = 20      # alimenta el DHT22 para poder reiniciarlo si se cuelga
PIN_SUELO_ADC = 26        # salida AO del sensor de suelo
PIN_SUELO_ENERGIA = 17    # alimenta el sensor de suelo solo al leer
PIN_SDA = 4               # reloj DS3231
PIN_SCL = 5
PIN_RELE = 16             # rele de la bomba
PIN_LED_VERDE = 18
PIN_LED_ROJO = 19

# Pantalla TFT ILI9341 y tactil XPT2046 (comparten el SPI 1)
PIN_SCK = 10
PIN_MOSI = 11
PIN_MISO = 12
PIN_CS = 13
PIN_DC = 8
PIN_RESET = 9
PIN_TACTIL_CS = 7
PIN_TACTIL_IRQ = 6

# ---------- Pantalla ----------
ANCHO = 240
ALTO = 320
ESPEJO_X = False
ESPEJO_Y = True
ORDEN_BGR = True
INVERTIR_X = False        # voltea el eje X del tactil
INVERTIR_Y = False        # voltea el eje Y del tactil
TACTIL_X_MIN = 200        # valores en bruto del tactil en los bordes
TACTIL_X_MAX = 3900
TACTIL_Y_MIN = 200
TACTIL_Y_MAX = 3900

# ---------- Calibracion del sensor de suelo ----------
SUELO_SECO = 64500        # valor con el sensor en el aire
SUELO_MOJADO = 16000      # valor con el sensor en agua
MUESTRAS_PROMEDIO = 5     # cuantas lecturas se promedian

# ---------- Reglas de riego ----------
UMBRAL_SECO = 35          # % de humedad del suelo bajo el cual se riega
UMBRAL_HUMEDO = 60        # % al que se detiene el riego automatico
TEMP_CALOR = 28           # si la maxima de hoy en Lima pasa esto, "hace calor"
AJUSTE_CALOR = 10         # con calor se riega antes (umbral + 10)
TIEMPO_RIEGO_S = 8        # segundos de cada riego (se cambia en AJUST, de 2 a 20):
                          #   manual -> riega justo este tiempo
                          #   auto   -> para al llegar a UMBRAL_HUMEDO o a este tiempo
TIEMPO_FILTRA_S = 60      # espera despues de regar para que el agua se filtre
SUBIDA_MINIMA = 3         # % que debe subir la humedad despues de regar
FALLOS_PARA_ALERTA = 2    # valor al encender (se cambia en AJUST, de 1 a 5)
NO_REGAR_DE_NOCHE = True   # valor al encender; se cambia en AJUST
HORA_INICIO_RIEGO = 6     # solo riega automaticamente entre estas horas
HORA_FIN_RIEGO = 20

# ---------- Tiempos del programa ----------
INTERVALO_LECTURA_MS = 2000        # cada cuanto se leen los sensores
INTERVALO_CLIMA_MS = 30 * 60 * 1000  # cada cuanto se consulta el clima
PAUSA_TACTIL_MS = 400              # evita que un toque cuente dos veces
PARPADEO_MS = 300                  # velocidad del LED rojo al regar
INTERVALO_NUBE_MS = 5000           # cada cuanto se envia el estado a la nube
INTERVALO_ORDENES_MS = 500         # cada cuanto se revisan ordenes del celular
MOSTRAR_TIEMPOS = False            # True = imprime en Thonny cuanto tarda cada parte

# ---------- Registro ----------
MAX_REGISTROS = 20
ARCHIVO_REGISTRO = "riegos.txt"
