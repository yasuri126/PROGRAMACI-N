# nube.py - Envia el estado del invernadero por MQTT y recibe ordenes
# desde el celular. Usa la libreria del profe: ultramq.py
#
# Temas en el broker (los arma ultramq con MQTT_BASE):
#   la Pico ENVIA el estado  -> datos de humedad, temperatura, estado, modo...
#   la Pico RECIBE ordenes    -> {"accion": "regar"}  (o "detener", "cambiar_modo",
#                                "cambiar_noche", "umbral_mas", "umbral_menos",
#                                "fallos_mas", "fallos_menos", "tiempo_mas", "tiempo_menos",
#                                "reset_bomba")

import json
import config as cfg
import ultramq


class Nube:

    def __init__(self):
        self.conectada = False

    def conectar(self):
        try:
            ultramq.begin(cfg.WIFI_SSID, cfg.WIFI_CLAVE, cfg.MQTT_BROKER, cfg.MQTT_BASE)
            self.conectada = True
        except Exception as error:
            print("No se pudo conectar a la nube:", error)
            self.conectada = False
        return self.conectada

    def enviar_estado(self, estado):
        # estado es un diccionario con los datos a mostrar en el celular
        if not self.conectada:
            return
        try:
            ultramq.send(estado)
        except Exception as error:
            print("Fallo al enviar:", error)
            self.conectada = False

    def revisar_orden(self):
        # Devuelve el nombre de la accion que pidio el celular, o None
        if not self.conectada:
            return None
        try:
            mensaje = ultramq.receive(timeout_ms=0)
        except Exception as error:
            print("Fallo al recibir:", error)
            self.conectada = False
            return None

        if not mensaje:
            return None
        # Si llega como texto, se convierte a diccionario
        if type(mensaje) is bytes:
            mensaje = mensaje.decode()
        if type(mensaje) is str:
            try:
                mensaje = json.loads(mensaje)
            except ValueError:
                return None
        if type(mensaje) is dict and "accion" in mensaje:
            return mensaje["accion"]
        return None
