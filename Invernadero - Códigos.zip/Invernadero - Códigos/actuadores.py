# actuadores.py - Lo que el sistema puede mover o prender: la bomba y los LEDs.

from machine import Pin
import time
import config as cfg


class Bomba:

    def __init__(self):
        self.encendida = False
        self.apagar()

    def encender(self):
        # El rele se activa cuando el pin esta en 0
        Pin(cfg.PIN_RELE, Pin.OUT, value=0)
        self.encendida = True

    def apagar(self):
        # El rele esta alimentado a 5 V y la Pico solo da 3,3 V, que no
        # alcanza para soltarlo. Por eso el pin se pone como entrada:
        # queda "desconectado", no pasa corriente y el rele se suelta.
        Pin(cfg.PIN_RELE, Pin.IN)
        self.encendida = False


class Indicadores:
    # LED verde = todo bien, rojo fijo = necesita agua, rojo parpadeando = regando

    def __init__(self):
        self.verde = Pin(cfg.PIN_LED_VERDE, Pin.OUT, value=0)
        self.rojo = Pin(cfg.PIN_LED_ROJO, Pin.OUT, value=0)
        self.ultimo_parpadeo = time.ticks_ms()

    def actualizar(self, estado, necesita_agua):
        if estado == "REGANDO":
            self.verde.off()
            # Parpadeo sin detener el programa (no usa sleep)
            ahora = time.ticks_ms()
            if time.ticks_diff(ahora, self.ultimo_parpadeo) >= cfg.PARPADEO_MS:
                self.rojo.toggle()
                self.ultimo_parpadeo = ahora
        elif estado == "SIN AGUA" or necesita_agua:
            self.verde.off()
            self.rojo.on()
        else:
            self.verde.on()
            self.rojo.off()
