# registro.py - Historial de riegos. Se guarda en un archivo de la Pico,
# asi no se pierde aunque se desconecte.

import config as cfg


class Registro:

    def __init__(self):
        self.riegos = []
        self.cargar()

    def cargar(self):
        try:
            archivo = open(cfg.ARCHIVO_REGISTRO, "r")
            for linea in archivo:
                linea = linea.strip()
                if linea != "":
                    self.riegos.append(linea)
            archivo.close()
        except OSError:
            pass            # la primera vez el archivo todavia no existe
        while len(self.riegos) > cfg.MAX_REGISTROS:
            self.riegos.pop(0)

    def agregar(self, hora, riego):
        # Ejemplo de linea: "23/11 14:05 auto 8s 32%>61%"
        linea = "{:02d}/{:02d} {:02d}:{:02d} {} {}s {}%>{}%".format(
            hora[2], hora[1], hora[3], hora[4],
            riego["tipo"], riego["duracion"], riego["antes"], riego["despues"])
        self.riegos.append(linea)
        if len(self.riegos) > cfg.MAX_REGISTROS:
            self.riegos.pop(0)
        try:
            archivo = open(cfg.ARCHIVO_REGISTRO, "a")
            archivo.write(linea + "\n")
            archivo.close()
        except OSError:
            print("No se pudo guardar el registro")

    def ultimos(self, cantidad):
        return self.riegos[-cantidad:]

    def riegos_de_hoy(self, hora):
        hoy = "{:02d}/{:02d}".format(hora[2], hora[1])
        contador = 0
        for linea in self.riegos:
            if linea.startswith(hoy):
                contador = contador + 1
        return contador
