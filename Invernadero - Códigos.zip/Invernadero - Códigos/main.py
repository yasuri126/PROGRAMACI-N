# main.py - Invernadero automatizado con riego inteligente.
# Este archivo solo coordina: los detalles estan en cada modulo.

import time
import config as cfg
import red
from pantalla import Pantalla, Tactil
from interfaz import Interfaz
from sensores import SensorAmbiente, SensorSuelo
from hora import Hora
from actuadores import Bomba, Indicadores
from riego import ControlRiego
from registro import Registro
from clima import Clima
from nube import Nube

# ---------- 1. Crear todos los objetos ----------
pantalla = Pantalla()
tactil = Tactil(pantalla)
interfaz = Interfaz(pantalla)
bomba = Bomba()                 # se crea primero para que arranque apagada
leds = Indicadores()

interfaz.mensaje("Conectando...")
hay_wifi = red.conectar(cfg.WIFI_SSID, cfg.WIFI_CLAVE)

reloj = Hora()
if hay_wifi:
    reloj.sincronizar_con_internet()

ambiente = SensorAmbiente()
suelo = SensorSuelo()
riego = ControlRiego()
registro = Registro()
clima = Clima()
nube = Nube()
if hay_wifi:
    clima.actualizar()
    if cfg.USAR_NUBE:
        nube.conectar()


def armar_datos():
    # Junta todo lo que la pantalla necesita mostrar
    return {
        "hora": hora,
        "estado": riego.estado,
        "modo": riego.modo,
        "umbral": riego.umbral_actual(clima.hace_calor()),
        "umbral_base": riego.umbral,
        "no_regar_de_noche": riego.no_regar_de_noche,
        "intentos": riego.intentos_sin_agua,
        "tiempo_riego": riego.tiempo_riego,
        "necesita_agua": riego.necesita_agua(humedad_suelo, clima.hace_calor()),
        "hum_suelo": humedad_suelo,
        "temp": ambiente.temperatura,
        "hum_aire": ambiente.humedad,
        "dht_ok": ambiente.funciona,
        "riegos_hoy": registro.riegos_de_hoy(hora),
        "historial": registro.ultimos(14),
        "clima": clima,
        "wifi": red.esta_conectado(),
        "nube": nube.conectada,
    }


def armar_estado_para_nube():
    # Solo numeros y textos, que es lo que viaja por MQTT
    ultimo = ""
    if len(registro.riegos) > 0:
        ultimo = registro.riegos[-1]
    return {
        "hora": "{:02d}:{:02d}".format(hora[3], hora[4]),
        "estado": riego.estado,
        "modo": riego.modo,
        "hum_suelo": humedad_suelo,
        "umbral": riego.umbral_actual(clima.hace_calor()),
        "umbral_base": riego.umbral,
        "tiempo_riego": riego.tiempo_riego,
        "fallos": riego.intentos_sin_agua,
        "temp": ambiente.temperatura,
        "hum_aire": ambiente.humedad,
        "bomba": bomba.encendida,
        "no_regar_de_noche": riego.no_regar_de_noche,
        "riegos_hoy": registro.riegos_de_hoy(hora),
        "ultimo_riego": ultimo,
        "lluvia": clima.prob_lluvia,          # probabilidad de lluvia hoy (%)
        "temp_max": clima.temp_maxima,        # maxima de hoy en Lima
    }


def ejecutar_accion(accion):
    # La misma accion puede venir de la pantalla o del celular
    if accion == "cambiar_modo":
        riego.cambiar_modo()
    elif accion == "regar":
        riego.pedir_riego_manual()
    elif accion == "detener":
        riego.detener_riego()
    elif accion == "cambiar_noche":
        riego.cambiar_noche()
    elif accion == "umbral_menos":
        riego.cambiar_umbral(-5)
    elif accion == "umbral_mas":
        riego.cambiar_umbral(5)
    elif accion == "fallos_menos":
        riego.cambiar_intentos(-1)
    elif accion == "fallos_mas":
        riego.cambiar_intentos(1)
    elif accion == "tiempo_menos":
        riego.cambiar_tiempo(-1)
    elif accion == "tiempo_mas":
        riego.cambiar_tiempo(1)
    elif accion == "reset_bomba":
        riego.reset_bomba()


def decidir_y_mover():
    # Aplica las reglas de riego y prende o apaga la bomba segun el resultado
    riego_terminado = riego.actualizar(humedad_suelo, hora[3], clima.hace_calor())
    if riego_terminado is not None:
        registro.agregar(hora, riego_terminado)

    if riego.bomba_debe_estar_encendida():
        bomba.encender()
    elif bomba.encendida:
        # La bomba se acaba de apagar: se reinicia el DHT22
        bomba.apagar()
        ambiente.reiniciar()
    else:
        bomba.apagar()


# ---------- 2. Primera lectura ----------
hora = reloj.ahora()
ambiente.leer()
humedad_suelo = suelo.leer_porcentaje()
interfaz.dibujar_todo(armar_datos())

ultima_lectura = time.ticks_ms()
ultimo_clima = time.ticks_ms()
ultimo_toque = time.ticks_ms()
ultimo_envio = time.ticks_ms()
ultima_orden = time.ticks_ms()

# ---------- 3. Bucle principal ----------
try:
    while True:
        ahora = time.ticks_ms()

        # a) Cada 2 segundos: leer sensores, decidir y mostrar
        if time.ticks_diff(ahora, ultima_lectura) >= cfg.INTERVALO_LECTURA_MS:
            ultima_lectura = ahora
            t0 = time.ticks_ms()
            hora = reloj.ahora()
            # Con la bomba prendida el DHT22 no responde (ruido del motor):
            # se guardan los ultimos valores y se lee cuando se apague
            if not bomba.encendida:
                ambiente.leer()
            humedad_suelo = suelo.leer_porcentaje()
            t1 = time.ticks_ms()

            decidir_y_mover()
            t2 = time.ticks_ms()
            interfaz.actualizar(armar_datos())
            if cfg.MOSTRAR_TIEMPOS:
                print("sensores:", time.ticks_diff(t1, t0), "ms  decidir:",
                      time.ticks_diff(t2, t1), "ms  pantalla:",
                      time.ticks_diff(time.ticks_ms(), t2), "ms")

        # b) Cada 30 minutos: actualizar el clima (y reconectar si se cayo)
        if time.ticks_diff(ahora, ultimo_clima) >= cfg.INTERVALO_CLIMA_MS:
            ultimo_clima = ahora
            if not red.esta_conectado():
                red.conectar(cfg.WIFI_SSID, cfg.WIFI_CLAVE)
            if red.esta_conectado():
                clima.actualizar()
                if cfg.USAR_NUBE and not nube.conectada:
                    nube.conectar()

        # c) Cada 5 segundos: enviar el estado a la nube
        if time.ticks_diff(ahora, ultimo_envio) >= cfg.INTERVALO_NUBE_MS:
            ultimo_envio = ahora
            t0 = time.ticks_ms()
            nube.enviar_estado(armar_estado_para_nube())
            if cfg.MOSTRAR_TIEMPOS:
                print("enviar a la nube:", time.ticks_diff(time.ticks_ms(), t0), "ms")

        # d) Ordenes desde el celular
        if time.ticks_diff(ahora, ultima_orden) >= cfg.INTERVALO_ORDENES_MS:
            ultima_orden = ahora
            t0 = time.ticks_ms()
            accion = nube.revisar_orden()
            if cfg.MOSTRAR_TIEMPOS and time.ticks_diff(time.ticks_ms(), t0) > 50:
                print("revisar ordenes:", time.ticks_diff(time.ticks_ms(), t0), "ms")
            if cfg.MOSTRAR_TIEMPOS and accion is not None:
                print("orden recibida:", accion)
            if accion is not None:
                ejecutar_accion(accion)
                decidir_y_mover()                     # la bomba reacciona al instante
                interfaz.dibujar_contenido(armar_datos())   # y se dibuja una sola vez
                nube.enviar_estado(armar_estado_para_nube())  # avisa al celular

        # e) Pantalla tactil
        toque = tactil.leer()
        if toque is not None and time.ticks_diff(ahora, ultimo_toque) >= cfg.PAUSA_TACTIL_MS:
            ultimo_toque = ahora
            accion = interfaz.revisar_toque(toque[0], toque[1])
            if accion is not None:
                ejecutar_accion(accion)
                decidir_y_mover()                     # la bomba reacciona al instante
                interfaz.dibujar_contenido(armar_datos())   # y se dibuja una sola vez
                nube.enviar_estado(armar_estado_para_nube())  # avisa al celular

        # f) LEDs (el parpadeo necesita revisarse seguido)
        leds.actualizar(riego.estado, riego.necesita_agua(humedad_suelo, clima.hace_calor()))

        time.sleep_ms(20)

finally:
    # Pase lo que pase (error o Stop en Thonny), la bomba queda apagada
    bomba.apagar()
